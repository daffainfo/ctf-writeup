If you are reading this message, it means that you've fatally crashed the webserver (see launch.sh).
Please go back and restart the challenge to try again.