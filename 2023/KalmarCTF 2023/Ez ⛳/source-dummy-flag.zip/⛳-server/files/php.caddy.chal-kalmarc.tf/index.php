<?php

echo "I can't get this to work :/";
echo system("cat flag.txt");

?>
