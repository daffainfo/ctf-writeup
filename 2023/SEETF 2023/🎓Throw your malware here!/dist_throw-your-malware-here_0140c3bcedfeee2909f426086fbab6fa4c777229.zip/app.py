from typing import Optional
import zipfile
import random
import shutil
import string
import subprocess
from pathlib import Path

import pefile
from fastapi import FastAPI, HTTPException, UploadFile
from fastapi.responses import JSONResponse


FILE_CACHE = Path("/app/cache")
FLOSS_PATH = Path("/usr/local/bin/floss")

app = FastAPI()


def get_random_string(length: int = 16) -> str:
    # choose from all lowercase letter
    letters = string.ascii_lowercase
    return "".join(random.choice(letters) for _ in range(length))


@app.on_event("startup")
def startup():
    # Ensure caches exist
    if not FILE_CACHE.is_dir():
        FILE_CACHE.mkdir()


def run_floss(target: Path) -> str:
    args = [str(target), "--json"]
    try:
        pefile.PE(name=str(target))
    except pefile.PEFormatError:
        args.extend(("--only", "static"))
    output = subprocess.check_output((FLOSS_PATH, *args))
    return output.decode()


@app.post("/floss")
def floss_endpoint(sample: UploadFile, password: Optional[str]) -> JSONResponse:
    random_path = get_random_string()
    while (target_path := FILE_CACHE / random_path).exists():
        random_path = get_random_string()
    with target_path.open("wb+") as f:
        shutil.copyfileobj(sample.file, f)
    is_zipfile = zipfile.is_zipfile(target_path)
    if is_zipfile:
        with zipfile.ZipFile(target_path) as f:
            # No zip bombs!
            file_size_sum = sum(data.file_size for data in f.filelist)
            compressed_size_sum = sum(data.compress_size for data in f.filelist)
            if (file_size_sum / compressed_size_sum > 10):
                raise HTTPException(413, "Zip Bomb Detected")

            zipobjects = f.infolist()
            if any(zipobject.file_size > 50000 for zipobject in zipobjects):
                raise HTTPException(418, "I'm a teapot!")
            files = f.namelist()
        args = ["unzip"]
        if password:
            args.extend(("-P", password))
        args.extend((str(target_path), "-d", f"{FILE_CACHE / random_path}-zip"))
        a = subprocess.run(args)
        if a.returncode != 0:
            raise HTTPException(422, "Invalid password!")
        targets = [FILE_CACHE / f"{random_path}-zip" / file for file in files]
    else:
        targets = [target_path]
    results = [run_floss(target) for target in targets]
    return JSONResponse(
        {target.name: result for target, result in zip(targets, results)}
        if is_zipfile
        else results[0]
    )
