# Text Adventure API

Tour my kitchen!

## Running

```
docker compose up
```

Then make api requests to `http://localhost:5000/api` with an `curl` or your favorite HTTP client.
