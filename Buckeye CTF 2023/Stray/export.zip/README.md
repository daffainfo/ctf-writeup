# Stray

Stuck on what to name your stray cat?

## Running

```
docker compose up
```

Then access [http://localhost:3000](http://localhost:3000) in your browser.
