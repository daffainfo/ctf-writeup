#!/bin/bash
docker build -t gitmeow .
docker run --rm  -it gitmeow
