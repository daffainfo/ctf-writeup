#!/bin/sh

# Secure entrypoint
# Initialize & Start MariaDB
mkdir -p /run/mysqld
chown -R mysql:mysql /run/mysqld
mysql_install_db --user=mysql --ldata=/var/lib/mysql
mysqld --user=mysql --console --skip-networking=0 &

# Wait for mysql to start
while ! mysqladmin ping -h'localhost' --silent; do echo 'not up' && sleep .2; done

mysql -u root << EOF

CREATE DATABASE eatmorecookies;
CREATE TABLE eatmorecookies.users (
    id INTEGER PRIMARY KEY AUTO_INCREMENT,
    username varchar(255) NOT NULL UNIQUE,
    password varchar(255) NOT NULL
);

CREATE TABLE eatmorecookies.cookies (
    id INTEGER PRIMARY KEY AUTO_INCREMENT,
    flavor varchar(255) NOT NULL,
    name varchar(255) NOT NULL
);

CREATE USER 'WSUuser'@'localhost' IDENTIFIED BY 'WayneStateUniversity';
GRANT ALL ON *.* TO 'WSUuser'@'localhost';
INSERT INTO eatmorecookies.cookies (flavor, name) VALUES ('chocolate chip', 'Smores');
INSERT INTO eatmorecookies.cookies (flavor, name) VALUES ('chocolate chip', 'Triple Chocolate');
INSERT INTO eatmorecookies.cookies (flavor, name) VALUES ('chocolate chip', 'Double Chocolate Chips');
INSERT INTO eatmorecookies.cookies (flavor, name) VALUES ('chocolate chip', 'Peanut Butter Chocolate Chip');
INSERT INTO eatmorecookies.cookies (flavor, name) VALUES ('chocolate chip', 'Mint Chocolate Chip');
INSERT INTO eatmorecookies.cookies (flavor, name) VALUES ('chocolate chip', 'Gluten Free Chocolate Chip');
INSERT INTO eatmorecookies.cookies (flavor, name) VALUES ('chocolate chip', 'Coconut Chocolate Chip');
INSERT INTO eatmorecookies.cookies (flavor, name) VALUES ('oatmeal raisin', 'Cranberry Oatmeal Raisin');
INSERT INTO eatmorecookies.cookies (flavor, name) VALUES ('peanut butter', 'Reeses Peanut Butter Cup');
INSERT INTO eatmorecookies.cookies (flavor, name) VALUES ('sugar', 'Classic Sugar Cookie');
INSERT INTO eatmorecookies.cookies (flavor, name) VALUES ('snickerdoodle', 'Cinnamon Swirl Snickerdoodle');
INSERT INTO eatmorecookies.cookies (flavor, name) VALUES ('gingerbread', 'Spiced Gingerbread');
INSERT INTO eatmorecookies.cookies (flavor, name) VALUES ('shortbread', 'Buttery Shortbread');
INSERT INTO eatmorecookies.cookies (flavor, name) VALUES ('coconut', 'Toasted Coconut Macaroon');
INSERT INTO eatmorecookies.cookies (flavor, name) VALUES ('lemon', 'Lemon Burst Cookie');
INSERT INTO eatmorecookies.cookies (flavor, name) VALUES ('almond', 'Almond Joy');
INSERT INTO eatmorecookies.cookies (flavor, name) VALUES ('caramel', 'Salted Caramel Delight');
INSERT INTO eatmorecookies.cookies (flavor, name) VALUES ('dark chocolate', 'Decadent Dark Delight');
INSERT INTO eatmorecookies.cookies (flavor, name) VALUES ('dark chocolate', 'Rich Chocolate Indulgence');
INSERT INTO eatmorecookies.cookies (flavor, name) VALUES ('white chocolate', 'Blissful White Delight');
INSERT INTO eatmorecookies.cookies (flavor, name) VALUES ('white chocolate', 'Creamy White Dream');
INSERT INTO eatmorecookies.cookies (flavor, name) VALUES ('mint chocolate', 'Refreshing Mint Swirl');
INSERT INTO eatmorecookies.cookies (flavor, name) VALUES ('mint chocolate', 'Minty Chocolate Sensation');
INSERT INTO eatmorecookies.cookies (flavor, name) VALUES ('oatmeal', 'Hearty Oatmeal Raisin');
INSERT INTO eatmorecookies.cookies (flavor, name) VALUES ('oatmeal', 'Chewy Oatmeal Chunk');
INSERT INTO eatmorecookies.cookies (flavor, name) VALUES ('peanut butter', 'Peanut Butter Bliss');
INSERT INTO eatmorecookies.cookies (flavor, name) VALUES ('peanut butter', 'Nutty Peanut Delight');
INSERT INTO eatmorecookies.users (username, password) VALUES ('Administrator', '\$2b\$10\$hJMMSSOOYbvcVtoIOq4kG.Db8i1a5HwQVP3mdHd3jcPmezkurcsqi');
FLUSH PRIVILEGES;
EOF

node /app/src/app.js