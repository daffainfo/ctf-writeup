

const isAuthenticated = async (req, res, next) => {
    if(req.session.username){
        next();
    } else {
        const error = new Error("Not Authenticated");
        error.status = 401;

        next(error);
    }
}

module.exports = isAuthenticated;