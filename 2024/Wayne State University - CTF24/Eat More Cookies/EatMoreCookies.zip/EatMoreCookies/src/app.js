const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');
const session = require("express-session");
const mysql = require('mysql2');
const mySQLStore = require("express-mysql-session")(session);
const bcrypt = require('bcrypt');
const isAuthenticated = require("./middleware/authenticated");



const app = express();

const dbconfig = {
    user: 'WSUuser',
    host: 'localhost',
    database: 'eatmorecookies',
    password: 'WayneStateUniversity',
    port: 3306,
  };

const pool = mysql.createPool({...dbconfig, connectionLimit: 10});

const sessionStore = new mySQLStore({...dbconfig, connection: pool, createDatabaseTable: true})

app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');


app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended: true}))

app.use(
    session({
        name: "userCookie",
        store: sessionStore,
        secret: "redacted",
        resave: false,
        saveUninitialized: false,
        cookie: {maxAge: 24 * 60 * 60 * 1000, sameSite: "lax"},
        httpOnly: true,
    })
)


app.get('/', (req, res, next) => {
  if(req.session.username){
    return res.status(200).render("index", {cookies: []});
  } else {
    return res.status(302).redirect("/login");
  }
});

app.post("/register", async (req, res, next) => {

  const {username, password} = req.body;

  const hashedPassword = await bcrypt.hash(password, 10);

  try {
    const query = "INSERT INTO users (username, password) VALUES (?, ?)";

    pool.query(query, [username, hashedPassword], (err, result) => {

      if(err){
        console.log(err);
      }

      console.log("Data inserted successfully " + result);
    });

  } catch (error) {
    return next(error);
  }

  try {
    const adminCookieData = {"cookie":{"originalMaxAge":86400000,"expires":"2024-04-20T19:21:29.400Z","httpOnly":true,"path":"/", "sameSite": "lax"},"username":"Admin","isAdmin":true};
    const sessionId = 'WSUCTF{F4ke_Flag}';
    const expirationTimestamp = 1712172179;
    
  
    const serializedData = JSON.stringify(adminCookieData);
    
    
    const query = `INSERT INTO sessions (session_id, data, expires) VALUES (?, ?, ?)`;

  pool.query(query, [sessionId, serializedData, expirationTimestamp], (err, result) => {
    if (err) {
      console.log("Error inserting data into the database:", err);
      return next(err);
    } else {
      console.log("Data inserted successfully:", result);
    }
  });

  } catch(error){
    return next(error);
  }

  return res.json({message: "Successfully registered user!"})
})

app.get("/login", async (req, res, next) => {
    res.render("login");
})

app.get("/register", async (req, res, next) => {
      res.render("register");
});


app.get("/searchcookies", isAuthenticated, async (req, res, next) => {
  cookies = req.query.cookies;

  const query = `SELECT * FROM cookies WHERE flavor = "${cookies}"`;

    pool.query(query, (err, result) => {
      if(err){
        return next(err)
      }

    return res.status(200).render("index", {cookies: result || []})
    });
})


app.post("/login", async (req, res, next) => {
  const { username, password } = req.body;
  const query = 'SELECT * FROM users WHERE username = ? LIMIT 1';
    try {
    pool.query(query, [username], async (err, result) => {

      user = result[0];

      if(!user){
        return res.json({message: "User not found. Please try again."})
      }

      let comparePassword = await bcrypt.compare(password, user.password);
  
      if (comparePassword) {
        req.session.username = user.username;

        return res.json({message: "Logged in. Please visit the home page."})
      } else {
        return res.json({message: 'Invalid username or password'});
      }
    })
  } catch (err) {
    return next(err)
  }


});

app.use((err, req, res, next) => {
  console.error(err);

  const status = err.status || 500;
  const message = err.message || 'Internal Server Error';

  res.status(status).send(message);
});


app.listen(3000, "0.0.0.0", () => {
  console.log(`Server is running on port 3000`);
});