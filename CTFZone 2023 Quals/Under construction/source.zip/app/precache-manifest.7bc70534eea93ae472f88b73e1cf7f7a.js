self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "2d5f6580355808a3396f8ecc4c1e4ef5",
    "url": "/index.html"
  },
  {
    "revision": "4e60d041be62d421851f",
    "url": "/static/css/main.b6088dfd.chunk.css"
  },
  {
    "revision": "c330db7d54732d2083d0",
    "url": "/static/js/2.10242674.chunk.js"
  },
  {
    "revision": "4e60d041be62d421851f",
    "url": "/static/js/main.21ba69a7.chunk.js"
  },
  {
    "revision": "42ac5946195a7306e2a5",
    "url": "/static/js/runtime~main.a8a9905a.js"
  },
  {
    "revision": "ed68e212fd025092ab7478d31d3ffa23",
    "url": "/static/media/logo.ed68e212.png"
  }
]);